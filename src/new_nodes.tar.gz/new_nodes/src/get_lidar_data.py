#!/usr/bin/env python
import rospy
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
def callback(msg):
    print ("----------------------")
    print ('s1[0]') # value in the front direction of the laser beam
    print msg.ranges[0] #print the distance to the robot from the obstacle
    print ( 's2 [90]')
    print msg.ranges[90]
    print ( 's3 [180]')
    print msg.ranges[180]
    print ( 's4 [270]')
    print msg.ranges[270]
    print ( 's5 [359]')
    print msg.ranges[359]
    if(msg.ranges[0] > 0.5):
      move.linear.x = 0.5
      move.linear.z = 0.0
    else:
     move.linear.x = 0.0
     move.linear.z = 0.0
    pub.publish(move)
rospy.init_node('laser_data')
sub = rospy.Subscriber('scan', LaserScan, callback)
pub = rospy.Publisher('cmd_vel',Twist)
move = Twist()
rospy.spin()
