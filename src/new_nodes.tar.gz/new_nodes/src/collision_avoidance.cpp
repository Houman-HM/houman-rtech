#include <ros/ros.h>
#include <std_msgs/String.h>
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/Twist.h>
#include <sstream>

void callback(const sensor_msgs::LaserScan::ConstPtr& msg){

    ss << "----------------------";
    ss << 's1[0]'; //# value in the front direction of the laser beam
    ss << msg.ranges[0];// #print the distance to the robot from the obstacle
    ss << 's2 [90]';
    ss << msg.ranges[90];
    ss << 's3 [180]';
    ss << msg.ranges[180];
    ss << 's4 [270]';
    ss << msg.ranges[270];
    ss << 's5 [359]';
    ss << msg.ranges[359];
    
    if(msg.ranges[0] > 0.5) {
      move.linear.x = 0.5;
      move.linear.z = 0.0;
    }
    else {
     move.linear.x = 0.0;
     move.linear.z = 0.0;
    }
    pub.publish(move);

}
int main(int argc, char **argv){
ros::init(argc, argv, "laser_data");
geometry_msgs::Twist move;
ros::NodeHandle n;
ros::Subscriber sub= n.subscribe("scan", LaserScan,callback);
ros::Publisher pub= n.advertise<geometry_msgs::Twist>("cmd_vel", 1000);
move = geometry_msgs::Twist();
return 0;
}